<script>
  import GetList from '../component/GetList.svelte'
</script>

<h1>Home sweet Home</h1>

<GetList />

